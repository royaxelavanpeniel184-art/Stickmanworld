# Stickman World Android

Tablet build route: upload this project to GitHub, open Actions, run **Build Stickman World APK**, then download the `StickmanWorld-debug-apk` artifact. Extract it and install the APK on Android.
